package com.klef.jfsd.sdp.agricultureapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgricultureappApplicationTests {

	@Test
	void contextLoads() {
	}

}
